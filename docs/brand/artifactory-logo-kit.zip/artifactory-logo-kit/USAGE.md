# Artifactory · 装配 A

2026-11-12。用户选择第 1 款。平顶大写 A 的横梁右侧保留一道装配切口，以单色轮廓表达构建与连接。

## 选用文件

| 使用位置 | 文件 |
|---|---|
| 浅色页面的完整名称 | `svg/artifactory-horizontal.svg` |
| 深色页面的完整名称 | `svg/artifactory-horizontal-dark.svg` |
| 单独使用 A | `svg/artifactory-symbol.svg` / `artifactory-symbol-gold.svg` |
| 纯黑 / 反白 | 对应的 `-black.svg` / `-white.svg` |
| 上下排列的图文组合 | `svg/artifactory-stacked.svg` / `-stacked-dark.svg` |
| 只有产品名称 | `svg/artifactory-wordmark.svg` / `-wordmark-dark.svg` |
| 浏览器页签 | `web/favicon.svg` / `web/favicon.ico` |
| 应用图标、头像 | `svg/artifactory-app-icon.svg` / `png/artifactory-app-icon-1024.png` |
| Apple / PWA 图标 | `web/apple-touch-icon.png`、`icon-192.png`、`icon-512.png`、`maskable-512.png` |
| 光栅版本 | `png/`，透明 PNG，文件名末尾标明宽度或方形边长 |
| 主展示图 | `presentation/artifactory-assembly-a.png` |
| 六种使用场景 | `presentation/presentation.html` 或 `presentation/slides/slide-04.png` |

`svg/` 和 `web/favicon.svg` 的图形与文字均为矢量路径，不依赖已安装字体。展示板上的说明文字单独排版。所有 PNG 使用 sRGB；白色透明 PNG 用于深色底，预览软件中的白底不代表文件空白。

## 配色

| 名称 | HEX | RGB | CMYK 估算 |
|---|---|---|---|
| 深绿 | `#101312` | 16 / 19 / 18 | 16 / 0 / 5 / 93 |
| 暖金 | `#E1BA75` | 225 / 186 / 117 | 0 / 17 / 48 / 12 |
| 深金 | `#80591D` | 128 / 89 / 29 | 0 / 30 / 77 / 50 |
| 纸白 | `#F4F5EE` | 244 / 245 / 238 | 0 / 0 / 3 / 4 |
| 深底文字 | `#ECEEE9` | 236 / 238 / 233 | 1 / 0 / 2 / 7 |

浅底优先用深绿，深底用暖金符号配米白文字。深金是浅底上的金色替代。暖金配深绿对比度约 10.22:1；深绿配纸白约 17.03:1；深金配纸白约 5.69:1。CMYK 是数学近似值；印刷时应按纸材和 ICC 配置打样，专色匹配尚未指定。

## 留白与尺寸

令 x 为横梁的高度，即 256 单位原图中的 32 单位。标志实际轮廓外围至少保留 1x 空间；文件内部已有的空边可计入这段距离。图形以等比例缩放为准。

| 版本 | 屏幕最小尺寸 |
|---|---|
| 标准符号 | 24 px 方形画布 |
| 小尺寸符号 / favicon | 16 px，使用专用小尺寸文件 |
| 横向图文组合 | 160 px 宽 |
| 上下图文组合 | 160 px 宽 |

标准符号横梁右侧的水平间隙为 24 单位；小尺寸版本扩大到 32 单位。反白符号的笔画略减薄，平衡深底上的视觉重量。页签采用更大的图形占比；应用图标留出较多空边。Maskable 图标使用完整方形底色，图形位于中央安全区域。

保持原有比例、角度、切口和图文间距；使用文件中的完整组合。照片或复杂背景上，可先加纯色承托区域。避免拉伸、旋转、渐变、阴影以及重新输入文字替代字标。

## 字体与网页使用

字标基于 IBM Plex Sans 600，调整字距后转为路径。`source/wordmark-type-study.svg` 中上方为 500、下方为最终采用的 600。SIL Open Font License 1.1 原文见 `licenses/IBM-Plex-Sans-OFL.txt`。界面正文可继续使用 IBM Plex Sans，中文回退到系统字体。

`web/head-snippet.html` 与 `site.webmanifest` 按网站根路径提供示例。集成时将相应资源置于公开目录，并调整子路径部署中的链接。清单引用的图标均已包含在 `web/` 中。

## 检查与源文件

`presentation/export-proof.png` 保留 16 / 24 / 32 / 64 px、反白、实际 PNG 像素放大和文字组合检查。`source/design.json` 保存精确几何与颜色；`source/approved-concept.svg` 保存所选概念。`SHA256SUMS` 可校验交付文件。

展示场景是品牌应用示意。本文档涵盖数字文件与基本使用规则；商标检索、印刷材料打样及平台上架验收不属于本次已完成的检查。
